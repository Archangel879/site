from django.contrib import admin
from django.urls import path, re_path
from firstapp import views

urlpatterns = [
    path('admin/', admin.site.urls),

    path('', views.index, name='home'),
    re_path(r'^about', views.about, name='about'),
    re_path(r'^contact', views.contact, name='contact'),

    # пз2 параметры из URL
    path('products/', views.products, name='products_default'),
    path('products/<int:productid>/', views.products, name='products'),
    path('users/', views.users, name='users_default'),
    path('users/<int:id>/<str:name>/', views.users, name='users'),


    # лз5 параметры из строки запроса
    path('products_query/<int:productid>/', views.products_query, name='products_query'),
    path('users_query/', views.users_query, name='users_query'),

    # лз5 переадресация
    path('contact_redirect/', views.contact_redirect, name='contact_redirect'),
    path('details/', views.details, name='details'),

    # лз5 статусные коды (ошибки)
    path('m304/', views.m304),
    path('m400/', views.m400),
    path('m403/', views.m403),
    path('m404/', views.m404),
    path('m405/', views.m405),
    path('m410/', views.m410),
    path('m500/', views.m500),

    path('form/', views.form_view, name='form'),

    path('persons/', views.persons_list, name='persons_list'),
    path('persons/create/', views.create_person, name='create_person'),

    path('persons/edit/<int:id>/', views.edit_person, name='edit_person'),
    path('persons/delete/<int:id>/', views.delete_person, name='delete_person'),

    path('companies/', views.companies_list, name='companies_list'),
    path('products_db/', views.products_list, name='products_list'),
    path('courses/', views.courses_list, name='courses_list'),
    path('students/', views.students_list, name='students_list'),
    path('users_db/', views.users_list, name='users_list'),
]