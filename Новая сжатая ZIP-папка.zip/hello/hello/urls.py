from django.contrib import admin
from django.urls import path
from firstapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path("", views.index, name='home'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),

    path('products/', views.products, name='products_default'),
    path('products/<int:productid>', views.products, name='products'),

    path('users/', views.users, name='users_default'),
    path('users/<int:id>/<str:name>', views.users,name='users'),
]