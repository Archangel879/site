from django.template.context import BaseContext, Context, RequestContext


def _patched_copy(self):
    duplicate = self.__class__.__new__(self.__class__)
    duplicate.__dict__.update(self.__dict__)
    duplicate.dicts = self.dicts[:]
    return duplicate


BaseContext.__copy__ = _patched_copy
Context.__copy__ = _patched_copy
RequestContext.__copy__ = _patched_copy