from django.http import (
    HttpResponse,
    HttpResponseRedirect,
    HttpResponsePermanentRedirect,
    HttpResponseNotModified,
    HttpResponseBadRequest,
    HttpResponseForbidden,
    HttpResponseNotFound,
    HttpResponseNotAllowed,
    HttpResponseGone,
    HttpResponseServerError,
)
from django.shortcuts import render
from .forms import UserForm
from .models import Person, Company, Product, Course, Student, User, Account


def index(request):
    data = {"age": 50}
    cat = ["Ноутбуки", "Принтеры", "Сканеры", "Диски", "Шнуры"]
    data["cat"] = cat
    return render(request, "firstapp/index.html", context=data)

def about(request):
    return render(request, "firstapp/about.html")

def contact(request):
    return HttpResponse("<h2>Контакты</h2>")

def products(request, productid=1):
    output = "<h2>Продукт № {0}</h2>".format(productid)
    return HttpResponse(output)

def users(request, id=1, name="Максим"):
    output = "<h2>Пользователь</h2><h3>id: {0} Имя: {1}</h3>".format(id, name)
    return HttpResponse(output)

def products_query(request, productid):
    category = request.GET.get("cat", "")
    output = "<h2>Продукт № {0} Категория: {1}</h2>".format(productid, category)
    return HttpResponse(output)

def users_query(request):
    id = request.GET.get("id", 1)
    name = request.GET.get("name", "Максим")
    output = "<h2>Пользователь</h2><h3>id: {0} Имя: {1}</h3>".format(id, name)
    return HttpResponse(output)


def contact_redirect(request):
    return HttpResponseRedirect("/about")

def details(request):
    return HttpResponsePermanentRedirect("/")

def m304(request):
    return HttpResponseNotModified()

def m400(request):
    return HttpResponseBadRequest("<h2>Bad Request</h2>")

def m403(request):
    return HttpResponseForbidden("<h2>Forbidden</h2>")

def m404(request):
    return HttpResponseNotFound("<h2>Not Found</h2>")

def m405(request):
    return HttpResponseNotAllowed(["GET"], "<h2>Method is not allowed</h2>")

def m410(request):
    return HttpResponseGone("<h2>Content is no longer here</h2>")

def m500(request):
    return HttpResponseServerError("<h2>Something is wrong</h2>")

def form_view(request):
    if request.method == "POST":
        userform = UserForm(request.POST)
        if userform.is_valid():
            name = userform.cleaned_data["name"]
            return HttpResponse("<h2>Имя введено корректно - {0}</h2>".format(name))
        else:
            return HttpResponse("Ошибка ввода данных")
    else:
        userform = UserForm()
        return render(request, "firstapp/form.html", {"form": userform})

from .models import Person

def persons_list(request):
    people = Person.objects.all()
    return render(request, "firstapp/persons.html", {"people": people})

def create_person(request):
    if request.method == "POST":
        name = request.POST.get("name")
        age = request.POST.get("age")
        Person.objects.create(name=name, age=age)
    return HttpResponseRedirect("/persons/")

def edit_person(request, id):
    try:
        person = Person.objects.get(id=id)
    except Person.DoesNotExist:
        return HttpResponseNotFound("<h2>Клиент не найден</h2>")
    if request.method == "POST":
        person.name = request.POST.get("name")
        person.age = request.POST.get("age")
        person.save()
        return HttpResponseRedirect("/persons/")
    else:
        return render(request, "firstapp/edit_person.html", {"person": person})

def delete_person(request, id):
    try:
        person = Person.objects.get(id=id)
        person.delete()
    except Person.DoesNotExist:
        return HttpResponseNotFound("<h2>Клиент не найден</h2>")
    return HttpResponseRedirect("/persons/")

def companies_list(request):
    companies = Company.objects.all()
    return render(request, "firstapp/companies.html", {"companies": companies})


def products_list(request):
    products = Product.objects.all()
    return render(request, "firstapp/products.html", {"products": products})


def courses_list(request):
    courses = Course.objects.all()
    return render(request, "firstapp/courses.html", {"courses": courses})


def students_list(request):
    students = Student.objects.all()
    return render(request, "firstapp/students.html", {"students": students})


def users_list(request):
    users = User.objects.all()
    return render(request, "firstapp/users.html", {"users": users})

